# WooCommerce Payment Gateway PayBy Plugin

## Description
WooCommerce plugin for user to purchase items using PayBy

### Requirement
1.  Support AED for currency

### Installation
1. Set up the Wordpress And Woocommerce
2. Log into the admin page
3. Press Plugins > Add Plugins/Add New
4. Upload the "payby.ocmod.zip" file
5. Click the "Install Now" button
6. Press Plugins > Installed Plugins
7. Click the "Activate" button in the column of Action in the row of the "WooCommerce Payby"

### Configuration
1. Press WooCommerce > settings
2. Choose Setting type 'Payments'
3. Click the "Enabled" button in the column of Action in the row of the "PayBy – Paypage"
4. Click the "Set up" button
5. Input the Subject provided
6. Input the Merchant Partner Id provided
7. Input the Merchant Private Key provided
8. Input the Payby Public Key provided
9. Select Run Mode Sandbox for testing, Production for general usage
10. Input PayBy Payment OrderNo Prefix like 'wp_'
11. Make Sure Already SET Store Currency - AED
12. Click the "Save" button

