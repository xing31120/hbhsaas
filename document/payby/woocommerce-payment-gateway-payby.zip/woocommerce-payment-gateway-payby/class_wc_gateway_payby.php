<?php

class WC_Gateway_Payby extends WC_Payment_Gateway
{

    /**
     * WC_Gateway_Payby constructor.
     */
    public function __construct()
    {
        $this->id = "payby-for-wc";
        $this->icon = WC_Payby_URL . "/assets/imgs/payby.png";
        $this->has_fields = false;
        $this->method_title = "PayBy";
        $this->method_description = "PayBy aims to build an all-in-one mobile payment ecosystem connecting people's daily life.";
        $this->title = "Paypage";
        $this->description = "PayBy aims to build an all-in-one mobile payment ecosystem connecting people's daily life.";

        $this->supports = array(
                'products',
                //'refunds',
            );

        $this->init_form_fields();
        $this->init_settings();

        if( !$this->is_valid_for_use() ){
            //$this->enabled = 'no';
        }
        $this->subject = $this->get_option("subject");
        $this->partner_id = $this->get_option("partner_id");
        $this->merchant_private_key = $this->get_option("merchant_private_key");
        $this->payby_public_key = $this->get_option("payby_public_key");
        $this->run_mode = $this->get_option("run_mode");
        $this->order_id_prefix = $this->get_option("order_id_prefix");


        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
    }

    /**
     * 配置列表项
     */
    public function init_form_fields()
    {
        $this->form_fields = array(
            'subject' => array(
                'title' => 'Subject',
                'type' => 'text',
                'default' => '',
                'description' => 'Your Payment Subject on the payment page',
                'css' => 'width:400px'
            ),
            'partner_id' => array(
                'title' => 'Partner Id',
                'type' => 'text',
                'default' => '',
                'description' => 'Your Parnter Id',
                'css' => 'width:400px'
            ),
            'merchant_private_key' => array(
                'title' => 'Merchant Private Key',
                'type' => 'textarea',
                'default' => '',
                'description' => 'Your Merchant Private Key',
                'css' => 'rows="5"'
            ),
            'payby_public_key' => array(
                'title' => 'PayBy Public Key',
                'type' => 'textarea',
                'default' => '',
                'description' => 'Your PayBy Public Key',
                'css' => 'rows="5"'
            ),
            'order_id_prefix' => array(
                'title' => 'PayBy Payment OrderNo Prefix',
                'type' => 'text',
                'default' => 'wp_',
                'description' => 'PayBy Payment OrderNo Prefix',
            ),
            'run_mode' => array(
                'title' => 'Run Mode',
                'type' => 'select',
                'options'     => array(
                    'live' => 'Live',
                    'sandbox'  => 'Sandbox',
                ),
            )
        );
    }

    /**
     * 支付方法
     * @param int $order_id
     * @return array
     */
    public function process_payment($order_id)
    {
        global $woocommerce;

        $order = new WC_Order($order_id);
        $total_amount = $order->get_total();
        $order_currency = $order->get_currency();

        if($order_currency != "AED"){
            wc_add_notice("PayBy does not support your store currency.!", 'error');
            return array(
                'result' => 'fail',
                'redirect' => $this->get_return_url($order)
            );
        }
        #woocommerce_currency

        $content_language = 'en';
        $sign_type = 'RSA2';
        $log_switch = false;
        $currency_code = "AED";

        $sim_gateway_host = "https://uat.test2pay.com";
        $live_gateway_host = "https://api.payby.com";

        $return_url = $this->get_return_url($order);
        $notify_url = add_query_arg('wc-api', 'wc_gateway_payby', home_url('/'));

        $gateway_path = array(
            'placeOrder' => "/sgs/api/acquire2/placeOrder",
            'cancelOrder' => "/sgs/api/acquire2/cancelOrder",
            'getOrder' => "/sgs/api/acquire2/getOrder",

            'refundOrder' => "/sgs/api/acquire2/refund/placeOrder",
            'refundGetOrder' => "/sgs/api/acquire2/refund/getOrder",
        );


        $config = array (
            'content_language'      => $content_language,
            'partner_id'            => $this->partner_id,
            'merchant_private_key'  => $this->merchant_private_key,
            'payby_public_key'      => $this->payby_public_key,
            'notify_url'            => $notify_url,
            'redirect_url'          => $return_url,
            'sign_type'             => $sign_type,
            'gateway_host'          => $this->run_mode == "sandbox" ? $sim_gateway_host : $live_gateway_host,
            'gateway_path'          => $gateway_path,
            'log_switch'            => $log_switch,
        );

        $builder = new PayPageBuilder($config);
        $builder->setRequestApi('placeOrder');
        $builder->setRequestTime(time()*1000);

        $bz = array(
            'merchantOrderNo'   => $this->order_id_prefix.$order_id,
            'subject'           => $this->subject,
            'totalAmount'       => array(
                                        "currency"=> $currency_code,
                                        "amount"=> $total_amount,
                                    ),
            #'expiredTime'=>(time()+$this->config->get('payment_payby_order_expire_seconds'))*1000,
            'payeeMid'=>$config['partner_id'],
            'paySceneCode'=>'PAYPAGE',

            'paySceneParams'=>array('redirectUrl'=>$config['redirect_url']),
            'notifyUrl'=>$config['notify_url'],
            #'accessoryContent'=>array(),
        );

        $builder->setBizContentarr($bz);

        $builder->generateSign();

        $payPage = new PbPayPage();

        $result=$payPage->request($builder);

        if(@$result['body']['interActionParams']['tokenUrl'] != ""){
            $tokenUrl = @$result['body']['interActionParams']['tokenUrl'];

            // Remove cart.
            WC()->cart->empty_cart();

            // 返重定向到支付表单
            return array(
                'result' => 'success',
                'redirect' => $tokenUrl
            );
        }
        else{
            wc_add_notice("Payby system error ".@$result['head']['code'].': '.$result['head']['msg'], 'error');
            return array(
                'result' => 'fail',
                'redirect' => $this->get_return_url($order)
            );
        }
    }

    public function process_refund( $order_id, $amount = null, $reason = '' ) {
        $order = new WC_Order($order_id);

        if ( ! $this->can_refund_order( $order ) ) {
            return new WP_Error( 'error', __( 'Refund failed.', 'woocommerce' ) );
        }

        $order_currency = $order->get_currency();

        if($order_currency != "AED"){
            return new WP_Error( 'error', "PayBy does not support your store currency.!" );
        }


        $content_language = 'en';
        $sign_type = 'RSA2';
        $log_switch = false;
        $currency_code = "AED";

        $sim_gateway_host = "https://uat.test2pay.com";
        $live_gateway_host = "https://api.payby.com";

        $return_url = $this->get_return_url($order);
        $notify_url = add_query_arg('wc-api', 'wc_gateway_payby', home_url('/'));

        $gateway_path = array(
            'placeOrder' => "/sgs/api/acquire2/placeOrder",
            'cancelOrder' => "/sgs/api/acquire2/cancelOrder",
            'getOrder' => "/sgs/api/acquire2/getOrder",

            'refundOrder' => "/sgs/api/acquire2/refund/placeOrder",
            'refundGetOrder' => "/sgs/api/acquire2/refund/getOrder",
        );


        $config = array (
            'content_language'      => $content_language,
            'partner_id'            => $this->partner_id,
            'merchant_private_key'  => $this->merchant_private_key,
            'payby_public_key'      => $this->payby_public_key,
            'notify_url'            => $notify_url,
            'redirect_url'          => $return_url,
            'sign_type'             => $sign_type,
            'gateway_host'          => $this->run_mode == "sandbox" ? $sim_gateway_host : $live_gateway_host,
            'gateway_path'          => $gateway_path,
            'log_switch'            => $log_switch,
        );

        $builder = new PayPageBuilder($config);
        $builder->setRequestApi('refundOrder');
        $builder->setRequestTime(time()*1000);

        $refund_orderno = 'refund-'.$this->order_id_prefix.$order_id.'-'.time();

        $bz = array(
            'refundMerchantOrderNo'=>$refund_orderno,
            'originMerchantOrderNo'=>$this->order_id_prefix.$order_id,
            'amount'=>array(
                "currency"=> $currency_code,
                "amount"=> $amount
            ),
        );

        if(@$reason != ""){
            $bz['reason'] = $reason;
        }

        $builder->setBizContentarr($bz);

        $builder->generateSign();

        $payPage = new PbPayPage();

        $result=$payPage->request($builder);


        if(isset($result['body']['refundOrder']) && @$result['body']['refundOrder']['status'] != "FAILURE"){
            $order->add_order_note(
                'Refunded '.$order_id.' - Refund Amount: '.$amount
            );
            return true;
        }

        return new WP_Error( 'error', 'Refund Failed '.@$result['head']['code'].': '.$result['head']['msg']);

    }

    public function is_valid_for_use() {
        return in_array(
            get_woocommerce_currency(),
            array( 'AED' ),
            true
        );
    }

    public function admin_options() {
        if ( $this->is_valid_for_use() ) {
            parent::admin_options();
        } else {
            ?>
            <div class="inline error">
                <p>
                    <strong><?php esc_html_e( 'Gateway disabled', 'woocommerce' ); ?></strong>: PayBy only support the currency (AED)
                </p>
            </div>
            <?php
        }
    }

    public function check_response($sign, $body){

        $sign_type = 'RSA2';
        $log_switch = false;

        $config = array (
            'payby_public_key'      => $this->payby_public_key,
            'sign_type'             => $sign_type,
            'log_switch'            => $log_switch,
        );

        $builder = new PayPageBuilder($config);

        if( $builder->verify($body, $sign) )
        {
            $body = json_decode($body, true);
            $merchantOrderNo = $body['acquireOrder']['merchantOrderNo'];
            $status = $body['acquireOrder']['status'];

            if("PAID_SUCCESS" == $status || "SETTLED" == $status)
            {
                $order_id = substr($merchantOrderNo, strlen($this->order_id_prefix));

                $order = new WC_Order($order_id);

                if ($order->needs_payment()) {
                    $order->payment_complete();
                }

                echo "SUCCESS";
                exit;
            }

        }

        echo "FAIL";
        exit;
    }

}
