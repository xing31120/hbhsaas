<?php
/*
 * Plugin Name: WooCommerce Payby
 * Plugin URI: https://www.payby.com
 * Description: Allow customers to pay with Payby gateway in your WooCommerce store.
 * Author: Payby company
 * Version: 0.9.1
 * Author URI:  https://www.payby.com
 */

if (!defined('ABSPATH'))
    exit (); // Exit if accessed directly

require_once("payby-sdk-php/init.php");

define('WC_Payby_URL', plugins_url('', __FILE__));     // 当前插件目录的URI

// 加载插件时，初始化自定义类
add_action('plugins_loaded', 'init_payby_gateway_class');
function init_payby_gateway_class()
{
    require_once("class_wc_gateway_payby.php");
    global $wc_getway_payby;
    $wc_getway_payby = new WC_Gateway_Payby();
}

// 告诉WC这个类的存在
add_filter('woocommerce_payment_gateways', 'add_payby_gateway_class');
function add_payby_gateway_class($methods)
{
    $methods[] = 'WC_Gateway_Payby';
    return $methods;
}

//添加hook钩子，设置回调函数
add_action('woocommerce_api_wc_gateway_payby', 'payby_notify');
function payby_notify()
{

    $body = @file_get_contents('php://input');

    $sign = $_SERVER['HTTP_SIGN'];

    $wc_getway_payby = new WC_Gateway_Payby();
    if ($wc_getway_payby->check_response($sign, $body)) {
        die("SUCCESS");
    } else {
        die("FAIL");
    }
}
